from setuptools import setup


setup(name='plot_helper',
        version='5.0',
        description='Collection of helper functions for a beautiful scientific plots made from matplotlib',
        author='ycnnn',
        license='MIT',
        packages=['plot_helper'])
