# Keithley interface

from pyvisa import VisaIOError
import numpy as np
from qcodes import (
    Measurement,
    initialise_database,
    new_experiment,
)
from qcodes.instrument_drivers.Keithley import Keithley2450 as kt
import time

def set_smu_ready(address="USB0::0x05E6::0x2450::04096331::INSTR"):
    smu = kt('Keithley',address)
    smu.reset()
    smu.terminals('front')
    smu.source.function('voltage')
    smu.source.voltage(0)
    return smu

def ramp(smu,current_voltage,target_voltage, steps=4, ramp_time=0):
    if np.abs(target_voltage) >= 180:
        print('Error: the voltage you requested is too large (> 180 V)')
        return
    ramp_volt = np.linspace(current_voltage, target_voltage,num=steps+1)
    for volt in ramp_volt[1:]:
        smu.source.voltage(volt)
        smu.sense.current()
        time.sleep(ramp_time/steps)
    return target_voltage