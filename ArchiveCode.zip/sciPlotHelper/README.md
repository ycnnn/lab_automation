# sciPlotHelper:
# V 1.1
# One-click solution to publication-quality scientific plots

# Update history:

2023-10-20

Ver 1.1 Fix the error of `abline` function where certain arguments are missing. 


2023-10-15

Ver 1 Initial version. Implement support for global font format, global figure size control, line object adjustment, label object format, scatter object format, box plot object format
