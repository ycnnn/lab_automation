**Pyhton Interface for Laser Scanning Microscopy (LSM), Ver 7**

**Yue Zhang**

Updates for Ver 7:
- Added functionality to save the channel image as `csv`.
- Optimized the piezo control to improve the stability.
- Fixed the error when the input `pixel` is 1
